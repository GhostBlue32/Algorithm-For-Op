function f2 = f2(x, y)
    f2 = (x + 1)^2 + (y + 1)^2 - 0.5 * sin(3 * x) + 0.6 * sin(5 * y);
end