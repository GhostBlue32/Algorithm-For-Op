function f1 = f1(x, y)
    f1 = (x - 2)^2 + (y - 2)^2 - 0.8 * cos(3 * x) + 0.7 * cos(5 * y);
end