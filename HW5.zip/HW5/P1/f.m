function fx = f(x1, x2)
    fx = (x1.^2 + x2.^2).^2 - 4 .* x1 + 3;
end