function T = make_distance_table(P)
  % Inputs:
  % P = 2xN matrix of col vectors specifying location of each city.
    
  T = dist(P);
  
end
