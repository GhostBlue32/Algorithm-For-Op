function gx = lgrad(x, A, b)
    gx = A * x - b;
end