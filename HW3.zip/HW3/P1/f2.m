function fx = f2(X)
    x1 = X(1);
    x2 = X(2);
    fx = x1.^2 / 4 + x2.^2 / 9;
end
